1. open main.m

2. modify the loading file name

3. run main.m and output the volumeloss between T0 and T3, for example.

