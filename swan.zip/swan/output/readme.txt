1. run check.m to draw the map of wave height (from SWAN) of study area.
2. run wind_exp.m to calculate the wind exposure of shoreline to SW wind.
3. run min_dist_swan.m to extract the nearest wave height point from the shoreline.
4. run wind_hs.m to correlate wind exposure to corresponding wave height, and plot the linear relation.