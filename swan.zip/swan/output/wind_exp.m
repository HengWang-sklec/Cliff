clear;

line=load('shore1.txt');  %%%
x0=line(:,1);
y0=line(:,2);

n=length(line);

fid=fopen('windexp.dat','wt');  %%%

for k=1:n-1
    arr_x=(y0(k+1)-y0(k));
    arr_y=(x0(k)-x0(k+1));
    A=arr_x+1i*arr_y;
    B=1+1i;
    angle1=acos(dot(A,B)/(norm(A)*norm(B)))*180/pi;   
     fprintf(fid,' %15.6f\n',...
     angle1);
end