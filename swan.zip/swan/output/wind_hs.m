clear;
clear all;



hs=load('hs_1.dat');
x0=hs(:,3);
y0=hs(:,4);


plot(x0,y0,'k.')
hold on


plot([90,90],[0,0.5],'k--');
hold on
%% ���
hold on 
skip0=(max(x0)-min(x0))/(length(x0)-1)*5;
y0000=[min(x0):skip0:max(x0)];
p=polyfit(x0,y0,1);%һ�����;
yfit=polyval(p,y0000);%����Ϻ��yֵ;
plot(y0000,yfit,'b:','LineWidth',3);%��ͼ;
hold on
%%
text(20,0.35, 'y=0.0019x','color','bl');
text(20,0.3, 'R^2=0.71','color','bl');
text(64,0.4, 'sheltered','color','k');
text(91,0.4, 'exposed','color','k');
%legend('Zuidogrs-C(pioneer)','Zuidogrs-B(bare)','Zuidogrs-A(bare)','Location','East');
% set(gca,'xtick',[0:10:100],'xticklabel',[0:10:100]);
% set(gca,'ytick',[-2:2:16],'yticklabel',[-2:2:16]);
xlabel('Wind exposure (Degree)','fontsize',10);
ylabel('Wave height (m)','fontsize',10);

set(gca,'XLim',[0,181]);
set(gca,'YLim',[0,0.45]);

set_xylabel('xlim',[0,180], [0,180],30,'%d');
set_xylabel('ylim',[0,0.45],[0,0.45],0.1,'%4.1f')

set(gcf,'Units','centimeters','Position',[2 2 15 10]);
%set(gcf,'paperpositionmode','auto');  %���ջ�����С����ͼ��  
set(gcf,'color',[1,1,1]);

set(gcf,'Units','centimeters','Position',[1 2 14 7]);
export_fig('TEST','-painters','-r600');
close(figure(1))
