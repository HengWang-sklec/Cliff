
%%
% clear;

IM=601;
JM=301;

type1='';
dir000='./';
%%
shorept=load('hs_1.dat');
x0=shorept(:,1);
y0=shorept(:,2);

%%
for k=11:11
    data=load(['data_' num2str(k) '.dat']);
    x=data(:,1);
    y=data(:,2);
    z=data(:,3);
    
    ii=(x==-999);
    x(ii)=nan;
    y(ii)=nan;
    z(ii)=nan;
    
    x=reshape(x,IM,JM);
    y=reshape(y,IM,JM);
    z=reshape(z,IM,JM);
    
%     contourf(x,y,z,[]);
    contourf(x,y,z,[0:0.01:0.4],'linestyle','none');
%     caxis([0 0.4])
    
    colormap(jet);
    
    hc=set_clabel([0 0.4],[0 0.4],0.1,...
        '%4.1f',[0.8 0.60 0.03 0.20]);
    set(hc,'fontsize',10);
    
    text(3.9,51.496,'wave height (m)','fontsize',10)
    hold on
    
    %plot(x0,y0,'k.');
    hold on
    
%     axis equal
    aspect(1/cos(51.4*pi/180));
%     axis([3.50 4.10 51.3 51.55])
    set_xylabel('xlim',[3.50 4.10], [3.50 4.10],0.1,'%4.1f');
    set_xylabel('ylim',[51.3 51.55],[51.3 51.6],0.1,'%4.1f')

%     axis equal
%     xlabel('Longitude (\circ)');
%     ylabel('Latitude (\circ)');
    
    xlabel('Longitude (\circ)','fontsize',10);
    ylabel('Latitude (\circ)','fontsize',10);

    set_gca(gca,10);
    set(gcf,'Units','centimeters','Position',[5 5 15 12]);
    
    fn=[num2str(k) '_HS.png'];
    png_f(fn,600,1);
    close(gcf)
    
end


