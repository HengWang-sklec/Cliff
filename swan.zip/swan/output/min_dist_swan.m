clear;

line=load('shore1382.txt');  %%%
x0=line(:,1);
y0=line(:,2);

hs=load('data_11.dat');
x=hs(:,1);
y=hs(:,2);
HS=hs(:,3);

wind=load('windexp.dat');
exp=wind(:,1);

fid=fopen('hs_1.dat','wt');  %%%


for k=1:length(line)
    arr_x=(x0(k)-x);
    arr_y=(y0(k)-y);
    dis=abs(arr_x+1i*arr_y);
    [Min,ii] = min(dis);
    HS(ii);
    fprintf(fid,' %15.6f %15.6f %15.8f %15.8f\n',...
        x(ii),y(ii),exp(k),HS(ii));
end

fclose(fid);



